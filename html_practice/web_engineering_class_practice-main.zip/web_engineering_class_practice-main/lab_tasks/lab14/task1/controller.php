<?php
$headlines = [
  "World Leaders Meet for Climate Summit",
  "New Tech Innovations Announced",
  "Sports Team Wins National Championship"
];
include 'view.php';
