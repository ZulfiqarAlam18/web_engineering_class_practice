<?php
	$name = $_GET['name'];
    $age = $_GET['age'];
    $caste = $_GET['caste'];


    echo "Name: $name <br>";
    echo "Age: $age <br>";
    echo "Caste: $caste <br>";
	
?> 
    