<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Zohaib's marriage next month , we all are gonna enjoy except zohaib himself</h1>
    
<?php
	$number = 1;
	
	
	switch ($number){
	  
	  
	  
	  case 1:
	    echo "Monday";
	    break;
	    case 2:
	      echo "Tuesday";
	      break;
	       case 3:
	      echo "Wed";
	      break;
	       case 4:
	      echo "thrus";
	      break;
	       case 5:
	      echo "Friday";
	      break;
	       case 6:
	      echo "Sat";
	      break;
	       case 7:
	      echo "Sun";
	      break;
	      default : 
	      echo "Error";
	      break;
	  
	  
	  
	  
	}
	
?> 
    


</body>
</html>























<!-- <?php
	$number = 1;
	
	
	switch ($number){
	  
	  
	  
	  case 1:
	    echo "Monday";
	    break;
	    case 2:
	      echo "Tuesday";
	      break;
	       case 3:
	      echo "Wed";
	      break;
	       case 4:
	      echo "thrus";
	      break;
	       case 5:
	      echo "Friday";
	      break;
	       case 6:
	      echo "Sat";
	      break;
	       case 7:
	      echo "Sun";
	      break;
	      default : 
	      echo "Error";
	      break;
	  
	  
	  
	  
	}
	
?> -->