<!-- / 	echo "Task 2";
	
	
// 	$salary = 5000;
// 	$Tax = 0;
	
// 	if ($salary > 100000) {
	  
	  
	  
// 	  $Tax = ($salary * 30)/100;
// 	  echo "30% Tax on amount $salary will be : $Tax";
	  
// 	}
// 	else if ($salary >50000 && $salary < 100000) {
	  
// 	  $Tax = ($salary * 20)/100;
// 	 echo "20% Tax on amount $salary will be : $Tax";
	  
	  
	  
// 	}
// 		else if ($salary >30000 && $salary < 50000) {
	  
// 	  $Tax = ($salary * 10)/100;
// 	   echo "10% Tax on amount $salary will be : $Tax";
	  
	  
// 	}
// 		else  {
	  
	  
// 	  echo "No Tax";
	  
// 	} -->