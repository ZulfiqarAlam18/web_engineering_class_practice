<?php

    $num = 5;
    $result = 1;

    for ( $i = 1; $i <= $num ; $i++){

        $result *= $i;



    }

    echo "$result";


?>